# Controlled failure testing

Use this guide when collecting the safe-failure evidence required by the
assessment. This test changes a local fictional-data database only. It does
not require changing or exposing a credential.

## Prepare

Reset the supplied database and confirm the endpoint works:

```bash
ddev mysql < database/schema.sql
ddev mysql < database/seed.sql
curl -k -i "https://bit607-a1-community-hub.ddev.site/api/equipment.php"
```

Keep the restoration command from the next section ready before triggering
the failure.

## Trigger and observe the failure

Temporarily rename one non-key column used by the endpoint:

```bash
ddev mysql -e "ALTER TABLE equipment RENAME COLUMN category TO category_failure_test;"
```

Request the endpoint and retain the response headers and body:

```bash
curl -k -i "https://bit607-a1-community-hub.ddev.site/api/equipment.php"
```

Inspect the local web-service log:

```bash
ddev logs -s web
```

Do not copy credentials or unrelated log content into your portfolio.

## Restore and confirm

Restore the original column name immediately:

```bash
ddev mysql -e "ALTER TABLE equipment RENAME COLUMN category_failure_test TO category;"
```

Repeat the normal request:

```bash
curl -k -i "https://bit607-a1-community-hub.ddev.site/api/equipment.php"
```

Confirm that the final submitted project is in normal working condition. If
the restoration command was interrupted, run it before doing any other
database work. As a final fallback, the supplied schema and seed scripts can
recreate the fictional database.
