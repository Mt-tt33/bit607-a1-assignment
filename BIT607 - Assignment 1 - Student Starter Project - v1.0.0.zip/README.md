# Southland Community Hub Equipment Loan Service

Starter version: **1.0.0**

This is the supplied plain-PHP starter project for BIT607 Assignment 1. It is
an intentionally imperfect service that you must review, diagnose, improve,
test, and document. Do not treat the starter code as an example of final
secure or maintainable practice.

## Prerequisites

- WSL 2 on Windows, or a supported Linux/macOS terminal
- Docker Desktop running
- DDEV installed
- a browser
- Bruno, Postman, or another tutor-approved API client

Check the main tools:

```bash
docker version
ddev version
```

## Start the project

From this project directory:

```bash
ddev start
```

The expected local URL is:

```text
https://bit607-a1-community-hub.ddev.site
```

If DDEV reports that the project name is already in use, stop and unlist the
other copy before starting this one:

```bash
ddev stop --unlist bit607-a1-community-hub
```

## Recreate the database

The submitted database must be reproducible without a local database volume.
Run both commands from the project root:

```bash
ddev mysql < database/schema.sql
ddev mysql < database/seed.sql
```

Running these commands returns the project to the supplied starting data. Any
loans you recorded while testing will be removed.

## Open the supplied workflows

- HTML catalogue and loan workflow:
  `https://bit607-a1-community-hub.ddev.site/`
- Assessed JSON endpoint:
  `https://bit607-a1-community-hub.ddev.site/api/equipment.php`

The HTML workflow should let you view equipment, record a loan, view active
loans, and mark an active loan as returned. The existing JSON endpoint accepts
a `GET` request and currently recognises the optional `category` and `limit`
query values. Its final required behaviour is defined in the assessment
descriptor.

## Open the API-client starter collection

The `api-client` folder contains
`BIT607-A1-Equipment-Service.postman_collection.json`. This is a neutral
Postman Collection v2.1 file that opens in Postman and can be imported into
Bruno.

- In Postman, import the JSON file.
- In Bruno, use **Import Collection**, select **Postman Collection**, then
  save the imported collection as a complete Bruno folder.
- Confirm the collection variable `baseUrl` matches the DDEV URL above.
- Run API-01 before changing code, then use the remaining requests as you
  investigate and verify the published endpoint behaviour.

The supplied descriptions state the behaviour you need to verify, but the
collection does not contain your completed actual-result evidence. Before
submission, export your completed Postman collection JSON or include the
complete Bruno collection folder in `api-client` or `evidence/api-client`.
Do not include an environment file containing live or personal credentials.

## Establish your baseline

Before changing code:

1. recreate the supplied database;
2. keep an untouched copy of this starter project;
3. record the behaviour of the HTML workflow and JSON endpoint;
4. complete each supplied black-box defect scenario exactly as written; and
5. save relevant request, response, log, browser, and database evidence.

The starter contains deliberate structural, validation, security, contract,
and reliability weaknesses. Investigate evidence before changing code. You
must correct the supplied scenarios as well as the wider requirements in the
assessment descriptor.

Useful diagnostic commands include:

```bash
ddev logs
ddev logs -s web
ddev mysql
```

Use `CONTROLLED-FAILURE-TESTING.md` for the reversible API failure check.
Always restore the database and confirm recovery before continuing.

## Stop the project

```bash
ddev stop
```

Use `ddev stop --unlist bit607-a1-community-hub` when you need to run another
copy that uses the same project name.
