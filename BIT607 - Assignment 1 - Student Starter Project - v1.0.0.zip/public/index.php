<?php
declare(strict_types=1);

$dsn = 'mysql:host=db;port=3306;dbname=db;charset=utf8mb4';

try {
    $pdo = new PDO($dsn, 'db', 'db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $equipment = $pdo
        ->query('SELECT id, name, category, is_available FROM equipment ORDER BY id')
        ->fetchAll(PDO::FETCH_ASSOC);

    $activeLoans = $pdo
        ->query(
            'SELECT loans.id, loans.borrower_reference, loans.loan_date,
                    loans.due_date, equipment.name AS equipment_name
             FROM loans
             INNER JOIN equipment ON equipment.id = loans.equipment_id
             WHERE loans.returned_at IS NULL
             ORDER BY loans.due_date, loans.id'
        )
        ->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $exception) {
    exit('<pre>Database error: ' . $exception->getMessage() . '</pre>');
}

$message = $_GET['message'] ?? '';
$defaultDueDate = date('Y-m-d', strtotime('+7 days'));
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Southland Community Hub Equipment</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<header>
    <h1>Southland Community Hub</h1>
    <p>Community equipment catalogue and active loans</p>
</header>
<main>
    <?php if ($message !== ''): ?>
        <p class="notice"><?= $message ?></p>
    <?php endif; ?>

    <section aria-labelledby="equipment-heading">
        <h2 id="equipment-heading">Equipment catalogue</h2>
        <div class="grid">
            <?php foreach ($equipment as $item): ?>
                <article class="card">
                    <h3><?= $item['name'] ?></h3>
                    <p>Category: <?= $item['category'] ?></p>
                    <?php if ($item['is_available']): ?>
                        <p class="status available">Available</p>
                        <form method="post" action="/loan.php">
                            <input type="hidden" name="equipment_id" value="<?= $item['id'] ?>">

                            <label for="borrower-<?= $item['id'] ?>">Borrower reference</label>
                            <input
                                id="borrower-<?= $item['id'] ?>"
                                name="borrower_reference"
                                placeholder="Fictional group reference"
                                required
                            >

                            <label for="due-<?= $item['id'] ?>">Due date</label>
                            <input
                                id="due-<?= $item['id'] ?>"
                                type="date"
                                name="due_date"
                                value="<?= $defaultDueDate ?>"
                                required
                            >

                            <button type="submit">Record loan</button>
                        </form>
                    <?php else: ?>
                        <p class="status unavailable">Currently on loan</p>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <section aria-labelledby="loans-heading">
        <h2 id="loans-heading">Active loans</h2>
        <?php if ($activeLoans === []): ?>
            <p>There are no active loans.</p>
        <?php else: ?>
            <div class="grid">
                <?php foreach ($activeLoans as $loan): ?>
                    <article class="loan">
                        <h3><?= $loan['equipment_name'] ?></h3>
                        <p>Borrower: <?= $loan['borrower_reference'] ?></p>
                        <p>Loan date: <?= $loan['loan_date'] ?></p>
                        <p>Due date: <?= $loan['due_date'] ?></p>
                        <form method="post" action="/return.php">
                            <input type="hidden" name="loan_id" value="<?= $loan['id'] ?>">
                            <button type="submit">Mark as returned</button>
                        </form>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <section aria-labelledby="api-heading">
        <h2 id="api-heading">Equipment feed</h2>
        <p>
            The supplied endpoint is
            <code>GET /api/equipment.php</code>.
        </p>
    </section>
</main>
</body>
</html>
