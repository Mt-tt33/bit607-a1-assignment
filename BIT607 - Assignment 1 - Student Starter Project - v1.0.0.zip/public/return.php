<?php
declare(strict_types=1);

$loanId = $_POST['loan_id'] ?? '';

if ($loanId === '') {
    header('Location: /?message=A loan identifier is required.');
    exit;
}

$dsn = 'mysql:host=db;port=3306;dbname=db;charset=utf8mb4';

try {
    $pdo = new PDO($dsn, 'db', 'db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $pdo->exec(
        "UPDATE loans
         SET returned_at = NOW()
         WHERE id = $loanId"
    );

    header('Location: /?message=Loan marked as returned.');
} catch (PDOException $exception) {
    header('Location: /?message=' . urlencode($exception->getMessage()));
}
