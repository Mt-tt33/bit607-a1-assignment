<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode(['message' => 'Only GET is supported.']);
    exit;
}

$category = trim((string) ($_GET['category'] ?? ''));
$limit = $_GET['limit'] ?? 20;
$dsn = 'mysql:host=db;port=3306;dbname=db;charset=utf8mb4';

try {
    $pdo = new PDO($dsn, 'db', 'db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "SELECT id, name, category, is_available
            FROM equipment
            ORDER BY id
            LIMIT $limit";

    $items = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'items' => $items,
        'total' => count($items),
        'requested_category' => $category,
    ]);
} catch (PDOException $exception) {
    echo json_encode([
        'error' => $exception->getMessage(),
    ]);
}
