<?php
declare(strict_types=1);

$equipmentId = $_POST['equipment_id'] ?? '';
$borrowerReference = trim((string) ($_POST['borrower_reference'] ?? ''));
$dueDate = $_POST['due_date'] ?? '';

if ($equipmentId === '' || $borrowerReference === '' || $dueDate === '') {
    header('Location: /?message=Please complete every loan field.');
    exit;
}

$dsn = 'mysql:host=db;port=3306;dbname=db;charset=utf8mb4';

try {
    $pdo = new PDO($dsn, 'db', 'db');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $loanDate = date('Y-m-d');
    $pdo->exec(
        "INSERT INTO loans (
            equipment_id,
            borrower_reference,
            loan_date,
            due_date
        ) VALUES (
            $equipmentId,
            '$borrowerReference',
            '$loanDate',
            '$dueDate'
        )"
    );

    $pdo->exec(
        "UPDATE equipment
         SET is_available = 0
         WHERE id = $equipmentId"
    );

    header('Location: /?message=Loan recorded.');
} catch (PDOException $exception) {
    header('Location: /?message=' . urlencode($exception->getMessage()));
}
