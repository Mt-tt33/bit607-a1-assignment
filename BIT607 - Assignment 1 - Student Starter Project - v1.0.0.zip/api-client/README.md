# Assignment 1 API-client starter collection

`BIT607-A1-Equipment-Service.postman_collection.json` is a neutral
Postman Collection v2.1 file. It can be opened in Postman or imported into
Bruno.

The only collection variable is `baseUrl`, which defaults to:

```text
https://bit607-a1-community-hub.ddev.site
```

The collection contains API-01 through API-19. Request descriptions identify
the published behaviour that you should verify. They do not contain your
actual-result evidence.

Before submitting:

- confirm `baseUrl` matches your final DDEV URL;
- complete and retain your own request/response evidence;
- document the final endpoint contract and examples;
- if you use Postman, export your completed collection JSON;
- if you import it into Bruno, save and submit the complete Bruno collection
  folder; and
- do not include an environment file containing live or personal credentials.

Before API-17, follow the separately supplied Controlled Failure Testing Guide
(also provided as `CONTROLLED-FAILURE-TESTING.md` inside the full student
starter project) and always restore the database before API-18.
