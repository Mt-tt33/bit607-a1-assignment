INSERT INTO equipment (id, name, category, is_available) VALUES
    (1, 'Portable Projector', 'presentation', 1),
    (2, 'Portable Speaker', 'audio', 1),
    (3, 'Folding Display Board', 'presentation', 1),
    (4, 'Community Sports Kit', 'sports', 1),
    (5, 'Event Gazebo', 'event-kits', 0),
    (6, 'Extension Lead', 'power', 1),
    (7, 'Wireless Microphone', 'audio', 1),
    (8, 'Table Tennis Set', 'sports', 1),
    (9, 'Portable Lighting Kit', 'event-kits', 1),
    (10, 'Compact PA System', 'audio', 1),
    (11, 'Adjustable Laptop Stand', 'presentation', 1),
    (12, 'Cable Ramp', 'safety', 1);

INSERT INTO loans (
    id,
    equipment_id,
    borrower_reference,
    loan_date,
    due_date,
    returned_at
) VALUES
    (
        1,
        2,
        'Winton Youth Group',
        '2026-06-10',
        '2026-06-17',
        '2026-06-16 14:30:00'
    ),
    (
        2,
        5,
        'Riverton Community Day',
        '2026-07-25',
        '2026-08-08',
        NULL
    );

ALTER TABLE equipment AUTO_INCREMENT = 13;
ALTER TABLE loans AUTO_INCREMENT = 3;
