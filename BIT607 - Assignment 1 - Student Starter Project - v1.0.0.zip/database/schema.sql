SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS loans;
DROP TABLE IF EXISTS equipment;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE equipment (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(30) NOT NULL,
    is_available TINYINT(1) NOT NULL DEFAULT 1,
    INDEX idx_equipment_category_id (category, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE loans (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    equipment_id INT UNSIGNED NOT NULL,
    borrower_reference VARCHAR(30) NOT NULL,
    loan_date DATE NOT NULL,
    due_date DATE NOT NULL,
    returned_at DATETIME NULL,
    CONSTRAINT fk_loans_equipment
        FOREIGN KEY (equipment_id) REFERENCES equipment (id),
    INDEX idx_loans_active_equipment (equipment_id, returned_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
